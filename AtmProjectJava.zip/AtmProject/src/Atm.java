import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Atm {
	
	
	void displayCustomers()
	{
		
		 try {
			
			  
			 DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			 
			 
			 // establish connection 
			 
			 Connection con = 
				DriverManager.getConnection("jdbc:mysql://localhost:3306/atm","root", "");
		             
			     if(con!=null)
			     {
			    	 System.out.println("Connected");
			     }
			     
			     // create a statement object 
			     
			     Statement st = con.createStatement();
			     
			     
			     String sql = "select * from customer";
			     
			     ResultSet rs =st.executeQuery(sql);
			     
			     while(rs.next())
			     {
			    	 System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5));
			     }
			     
			     rs.close();
			     st.close();
			     con.close();
			     
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	void updateCustomers()
	{
		
		Scanner sc  = new Scanner(System.in);
		
		System.out.println("Enter the customer id");
		
		String  cid = sc.next();
		
		System.out.println("Enter the Customer email");
		
		String  cemail = sc.next();
		
		
		try {
			
 DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			 
			 
			 // establish connection 
			 
		Connection con = 
				DriverManager.getConnection("jdbc:mysql://localhost:3306/atm","root", "");
		             
			     if(con!=null)
			     {
			    	 System.out.println("Connected");
			     }
			     
			     // create a statement object 
			     
			     Statement st = con.createStatement();
			     
			     
			     String sql = "update customer  set email = '"+cemail+"' where cid ='"+cid+"'";
		 
			     int x = st.executeUpdate(sql);
			     
			     if(x==1)
			     {
			    	 System.out.println("Customer info updated successfully");
			     }
			     else 
			     {
			    	 System.out.println("Customer id not found");
			     }
			     
			     st.close();
			     con.close();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	void deleteCustomers()
	{
		Scanner sc = new Scanner(System.in);
	   System.out.println("Enter the customer id to remove the record");
	   String cid = sc.next();
		 try {
			
 DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			 
			 
			 // establish connection 
			 
			 Connection con = 
				DriverManager.getConnection("jdbc:mysql://localhost:3306/atm","root", "");
		             
			     if(con!=null)
			     {
			    	 System.out.println("Connected");
			     }
			     
			     // create a statement object 
			     
			     Statement st = con.createStatement();
			     
			     
			     String sql = "delete from customer where cid='"+cid+"'";
			     
			     int x = st.executeUpdate(sql);
			     
			     if(x==1)
			     {
			    	 System.out.println("Customer delete successfully");
			     }
			     else
			     {
			    	 System.out.println("Customer id  not found");
			     }
			     st.close();
			     
			     con.close();
			     
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			
		}
	}
	void searchCustomers()
	{
		
            Scanner sc = new Scanner(System.in);
            
            System.out.println("Enter the custoemr id");
            String cid = sc.next();
		 try {
			
			  
			 DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			 
			 
			 // establish connection 
			 
			 Connection con = 
				DriverManager.getConnection("jdbc:mysql://localhost:3306/atm","root", "");
		             
			     if(con!=null)
			     {
			    	 System.out.println("Connected");
			     }
			     
			     // create a statement object 
			     
			     Statement st = con.createStatement();
			     
			     
			     String sql = "select * from customer";
			     
			     ResultSet rs =st.executeQuery(sql);
			     
			     while(rs.next())
			     {
			    	 if(rs.getString(1).equals(cid))
			    	 {
			    	 System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3));
			    	 }
			     }
			     
			     rs.close();
			     st.close();
			     con.close();
			     
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		
	}

	
	void insertCustomer()
	{
		  try {
			  
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter the cid");
        String cid = sc.next();
        
        System.out.println("Enter the Customer name");
        String cname = sc.next();
        
        System.out.println("Enter the Customer phone ");
        String cphone = sc.next();
        
        System.out.println("Enter the Customer email");
        String email = sc.next();
        	
        System.out.println("Enter the Customer address ");
        String address = sc.next();
         
			  // register the Driver 
			  
	 DriverManager.registerDriver(new com.mysql.jdbc.Driver());
	 
	 
	 // establish connection 
	 
	 Connection con = 
		DriverManager.getConnection("jdbc:mysql://localhost:3306/atm","root", "");
             
	     if(con!=null)
	     {
	    	 System.out.println("Connected");
	     }
	     
	     // create a statement object 
	     
	     Statement st = con.createStatement();
	     
	     String sql = "insert into customer values('"+cid+"','"+cname+"','"+cphone+"','"+email+"','"+address+"')";

	     System.out.println(sql);
	     
	    int x = st.executeUpdate(sql);
	    
	    if(x==1)
	    {
	    	System.out.println("Customer inserted successfully");
	    }
	    
	    st.close();
	    
	    con.close();
		  
		} catch (Exception e) {
			// TODO: handle exception
			
			e.printStackTrace();
		}
	}
	void checkCredential()
	{
		Scanner sc = new Scanner(System.in);
		
		while(true)
		{
			System.out.println("Enter the username");
			String uname = sc.next();
			System.out.println("Enter the password");
			String password = sc.next();
			
			if(uname.equals("ragasree") && password.equals("sk"))
			{
				System.out.println("Welcome to Admin "+uname);
				break;
			}
			else
			{
				System.out.println("wrong username and password");
			}
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Atm di = new Atm();
		
		
		System.out.println("Welcome to Customer Management System");
		System.out.println("***************************************");
		di.checkCredential();
		int ch;
		Scanner sc = new Scanner(System.in);
		
	     do 
	     {
	    	 System.out.println("1. Add New Customer");
	    	 System.out.println("2. Display Customers");
	    	 System.out.println("3. Update  Customers");
	    	 System.out.println("4. Delete Customers");
	    	 System.out.println("5. Search  Customer By cid"); 
	    	 System.out.println("6. Exit");
	    	 
	    	 ch = sc.nextInt();
	    	 
	    	 switch(ch)
	    	 {
	    	 case 1:
	    		        di.insertCustomer();
	    		        break;
	    	 case 2:
	    		         di.displayCustomers();
	    		         break;
	    	 case 3:
	    		         di.updateCustomers();
	    		         break;
	    	 case 4:
	    		         di.deleteCustomers();
	    		         break;
	    	 case 5:
	    		         di.searchCustomers();
	    		         break;
	    	
	    	 case 6:
	    		         System.out.println("Thank you");
	    		         break;
	         default:
	        	         System.out.println("Incorrect Choice");
	    		         break;
	    	 }
	     }
	     while(ch!=6);

	}

}
